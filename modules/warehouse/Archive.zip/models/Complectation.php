<?php

namespace app\modules\warehouse\models;

use Yii;

/**
 * This is the model class for table "s_comlectation".
 *
 * @property int $id
 * @property float|null $new_product_price
 * @property float|null $service_fee
 * @property int|null $new_product_count
 * @property string|null $created_at
 * @property int $nomenclature_product_id
 * @property int $provider_warehouse_id
 * @property int $supplier_warehouse_id
 */
class Complectation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 's_comlectation';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['new_product_price', 'service_fee'], 'number'],
            [['new_product_count', 'nomenclature_product_id', 'provider_warehouse_id', 'supplier_warehouse_id'], 'integer'],
            [['created_at'], 'safe'],
            [['nomenclature_product_id', 'provider_warehouse_id', 'supplier_warehouse_id'], 'required'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'new_product_price' => 'Նոր ապրանքի գին',
            'service_fee' => 'Սպասարկման գումար',
            'new_product_count' => 'Նոր ապրանքի քանակ',
            'created_at' => 'Ստեղծվել է',
            'nomenclature_product_id' => 'Ապրանքի Նոմենկլատուրա',
            'provider_warehouse_id' => 'Առաքող պահեստ',
            'supplier_warehouse_id' => 'Ստացող պահեստ',
        ];
    }
    public function getToWarehouse()
    {
        return $this->hasOne(Warehouse::class, ['id' => 'supplier_warehouse_id']);
    }
    public function getFromWarehouse()
    {
        return $this->hasOne(Warehouse::class, ['id' => 'provider_warehouse_id']);
    }
    public function getNProduct()
    {
        return $this->hasOne(NomenclatureProduct::class, ['id' => 'nomenclature_product_id']);
    }
}
