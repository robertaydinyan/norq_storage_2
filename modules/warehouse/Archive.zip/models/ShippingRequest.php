<?php

namespace app\modules\warehouse\models;

use Yii;
use app\models\User;

/**
 * This is the model class for table "s_shipping_request".
 *
 * @property int $id
 * @property int $count
 * @property string $created_at
 * @property int $nomenclature_product_id
 * @property int $shipping_id
 * @property int $shipping_type
 * @property int|null $supplier_id
 * @property string|null $invoice
 */
class ShippingRequest extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 's_shipping';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [[ 'created_at','shipping_type'], 'required'],
            [['created_at'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'count' => 'Քանակ',
            'created_at' => 'Created At',
            'nomenclature_product_id' => 'Ապրանքի Նոմենկլատուրա',
            'shipping_id' => 'Shipping ID',
            'shipping_type' => 'Տեսակ',
            'provider_warehouse_id' => 'Հանձնող պահեստ',
            'supplier_warehouse_id' => 'Ստացող պահեստ',
            'status' => 'Կարգավիճակ',
            'user_id' => 'Պատասխանատու'
        ];
    }

    public function getNProduct()
    {
        return $this->hasOne(NomenclatureProduct::class, ['id' => 'nomenclature_product_id']);
    }
    public function getShippingtype()
    {
        return $this->hasOne(ShippingType::class, ['id' => 'shipping_type']);
    }
    public function getStatus_()
    {
        return $this->hasOne(StatusList::class, ['id' => 'status']);
    }
    public function getProvider()
    {
        return $this->hasOne(Warehouse::class, ['id' => 'provider_warehouse_id']);
    }
    public function getSupplier()
    {
        return $this->hasOne(Warehouse::class, ['id' => 'supplier_warehouse_id']);
    }
    public function getSupplierp()
    {
        return $this->hasOne(SuppliersList::class, ['id' => 'supplier_id']);
    }
    public function getPartner()
    {
        return $this->hasOne(SuppliersList::class, ['id' => 'partner_id']);
    }
    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }
    public function getProducts()
    {
        return $this->hasMany(ShippingProducts::class, ['shipping_id' => 'id']);
    }

    public function getTotalsum() {

        $products = Yii::$app->db->createCommand("SELECT count,price FROM s_shipping_products WHERE shipping_id = $this->id")->queryAll();
        $sum = 0;
        if(!empty($products)){
            foreach ($products as $product => $prod_val){
                $sum += $prod_val['price'] * $prod_val['count'];
            }
            return $sum;
        } else {
            return 0;
        }

    }
    public function getTotalsumsale() {

        $products = Yii::$app->db->createCommand("SELECT count,price FROM s_shipping_products WHERE shipping_id = $this->id")->queryAll();
        $sum = 0;
        if(!empty($products)){
            foreach ($products as $product => $prod_val){
                $sum += $prod_val['price'] * $prod_val['count'];
            }
            return $sum;
        } else {
            return 0;
        }

    }

}
