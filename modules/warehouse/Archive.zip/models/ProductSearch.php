<?php

namespace app\modules\warehouse\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\modules\warehouse\models\Product;

/**
 * ProductSearch represents the model behind the search form of `app\modules\warehouse\models\Product`.
 */
class ProductSearch extends Product
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'warehouse_id', 'nomenclature_product_id'], 'integer'],
            [['price', 'retail_price'], 'number'],
            [['supplier_name', 'mac_address', 'comment', 'used', 'created_at'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    public function childTree(array $tableTreeGroups) {

        $result = [];


        foreach ($tableTreeGroups as $treeGroup) {
            if (!isset($treeGroup['children'])){
                $result[] = $treeGroup['id'];
            } else {
                $result = array_merge($result, $this->childTree($treeGroup['children']));
            }
        }
        return $result;
    }


    public function buildTree(array $elements, $parentId = null) {

        $branch = array();
        foreach ($elements as $element) {

            if ($element['group_id'] == $parentId) {

                $children = $this->buildTree($elements, $element['id']);

                if ($children) {

                    $element['children'] =  $children;

                }

                $branch[] = $element;

            }

        }
        return $branch;

    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Product::find()->select([
            's_product.id',
                's_product.price',
                's_product.retail_price',
                's_suppliers_list.name as supplier_name',
                's_product.mac_address',
                's_product.comment',
                's_product.count',
                's_product.warehouse_id',
                's_product.created_at',
                's_nomenclature_product.name as n_product_name',
                's_nomenclature_product.production_date as n_product_production_date',
                's_nomenclature_product.individual as n_product_individual',
                's_nomenclature_product.id as namiclature_id',
                's_qty_type.type as n_product_qty_type',
                's_group_product.name as group_name',
                's_warehouse.name as warehouse_name',
                's_warehouse.type as warehouse_type',
                's_qty_type.type as qty_type',
                'user.name as user_name',
                'user.role',
                'user.name as user_name',
                'user.last_name as user_lastname',
                'user.id as user_id',
                'contact_adress.region_id',
                'contact_adress.city_id',
                'contact_adress.street',
                'contact_adress.house',
                'contact_adress.housing',
                'contact_adress.apartment',
                'f_streets.name as street_name',
                'f_community.name as community_name',
                'regions.name as region_name',
                'cities.name as city_name'

            ])
            ->leftJoin('s_nomenclature_product', '`s_nomenclature_product`.`id`= `s_product`.`nomenclature_product_id`')
            ->leftJoin('s_group_product', '`s_group_product`.`id`= `s_nomenclature_product`.`group_id`')
            ->leftJoin('s_qty_type', '`s_qty_type`.`id`= `s_nomenclature_product`.`qty_type_id`')
            ->leftJoin('s_warehouse', '`s_warehouse`.`id`= `s_product`.`warehouse_id`')
            ->leftJoin('s_suppliers_list', '`s_suppliers_list`.`id`= `s_product`.`supplier_id`')
            ->leftJoin('user', '`user`.`id`= `s_warehouse`.`responsible_id`')
            ->leftJoin('contact_adress', '`contact_adress`.`id`= `s_warehouse`.`contact_address_id`')
            ->leftJoin('cities', '`cities`.`id`= `contact_adress`.`city_id`')
            ->leftJoin('f_community', '`f_community`.`id`= `contact_adress`.`community_id`')
            ->leftJoin('f_streets', '`f_streets`.`id`= `contact_adress`.`street`')
            ->leftJoin('regions', '`regions`.`id`= `contact_adress`.`region_id`');


        if (!empty($params['from_date'])) {
            $query->andWhere(['>=', 's_shipping.created_at' ,$params['from_date']]);
        }
        if (!empty($params['to_date'])) {
            $query->andWhere(['<=', 's_shipping.created_at' ,$params['to_date']]);
        }

        if (!empty($params['user_role'])) {
            if (!empty($params['user_id'])) {
                $query->andWhere(['user.id'=>$params['user_id'] ]);
            } else {
                $query->andWhere(['user.role'=>$params['user_role'] ]);
            }

        }
        if (!empty($params['show_mac'])) {

            if (!empty($params['Product']['mac_address'])) {
                $query->andWhere(['s_product.mac_address' => $params['Product']['mac_address']]);
            }
        }

        if (!empty($params['Product']['invoice'])) {
            $query->andWhere(['s_product.invoice' => $params['Product']['invoice']]);
        }
        if (!empty($params['ContactAdress']['region_id'])) {

            $query->andWhere(['contact_adress.region_id' => $params['ContactAdress']['region_id']]);
        }
        if (!empty($params['ContactAdress']['city_id'])) {
            $query->andWhere(['contact_adress.city_id' => $params['ContactAdress']['city_id']]);
        }
        if (!empty($params['ContactAdress']['community_id'])) {
            $query->andWhere(['contact_adress.community_id' => $params['ContactAdress']['community_id']]);
        }
        if (!empty($params['ContactAdress']['street'])) {
            $query->andWhere(['contact_adress.street' => $params['ContactAdress']['street']]);
        }
        if (!empty($params['ContactAdress']['housing'])) {
            $query->andWhere(['contact_adress.housing' => $params['ContactAdress']['housing']]);
        }
        if (!empty($params['ContactAdress']['house'])) {
            $query->andWhere(['contact_adress.house' => $params['ContactAdress']['house']]);
        }
        if (!empty($params['ContactAdress']['apartment'])) {
            $query->andWhere(['contact_adress.apartment' => $params['ContactAdress']['apartment']]);
        }

        if (!empty($params['nomenclature_product_id'])) {
            $query->andWhere(['s_nomenclature_product.id' => $params['nomenclature_product_id']]);
        }
        if (!empty($params['warehouse_id'])) {
            $query->andWhere(['s_warehouse.id' => $params['warehouse_id']]);
        }
        if (!empty($params['groups_id'])) {
            $groups = GroupProduct::find()->asArray()->all();
            $arrayChilds = $this->childTree($this->buildTree($groups, $params['groups_id']));

            if (!empty($arrayChilds)) {
                $query->andWhere(['in' , 's_group_product.id' , $arrayChilds]);
            } else {
                $query->andWhere(['s_group_product.id' => $params['groups_id']]);
            }

        }
        $query->andWhere(['s_product.status' => 1]);
        if (!empty($params['ContactAdress']['city_id'])) {
            $result = array_group_by( $query->asArray()->all(), "city_id", "n_product_name");
        } elseif (!empty($params['ContactAdress']['region_id'])) {
            $result = array_group_by( $query->asArray()->all(), "region_id", "n_product_name");
        } elseif (!empty($params['user_role'])) {
            $result = array_group_by( $query->asArray()->all(), "user_id", "n_product_name");
        } else {
            $result = array_group_by( $query->asArray()->all(), "warehouse_id", "n_product_name");
        }

        return ['result' => $result, 'params' => $params];
    }
}
