<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\modules\warehouse\models\Complectation */
/* @var $dataProvider app\modules\warehouse\models\Complectation */
/* @var $searchModel app\modules\warehouse\models\Complectation */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Complectations', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$this->registerCssFile('@web/css/modules/warehouse/custom-tree-view.css', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_READY]);
\yii\web\YiiAsset::register($this);
?>
<div class="complectation-view group-product-index" style="padding: 20px;">

    <div style="display: flex">
        <div class="col-lg-5">
            <h4 style="padding: 20px;">Կոմպլեկտացիա: <?= Html::encode($this->title) ?></h4>



            <?= DetailView::widget([
                'model' => $model,
                'attributes' => [
                    'id',
                    'new_product_price',
                    'service_fee',
                    'new_product_count',
                    'created_at',
                    [
                        'attribute' => 'nomenclature_product_id',
                        'label' => 'Առաքող պահեստ',
                        'value' => function ($model) {
                            return $model->nProduct->name;
                        }
                    ],

                    [
                        'attribute' => 'provider_warehouse_id',
                        'label' => 'Առաքող պահեստ',
                        'value' => function ($model) {
                            return $model->fromWarehouse->name;
                        }
                    ],
                    [
                        'attribute' => 'supplier_warehouse_id',
                        'label' => 'Ստացող պահեստ',
                        'value' => function ($model) {
                            return $model->toWarehouse->name;
                        }
                    ],
                ],
            ]) ?>
            <p>
                <?= Html::a('Փոփոխել', ['update', 'id' => $model->id], ['class' => 'btn btn-sm btn-primary']) ?>
                <?= Html::a('Ջնջել', ['delete', 'id' => $model->id], [
                    'class' => 'btn btn-sm btn-danger',
                    'data' => [
                        'confirm' => 'Are you sure you want to delete this item?',
                        'method' => 'post',
                    ],
                ]) ?>
            </p>
        </div>
        <div class="col-lg-7" style="margin-top:-8px;">
            <br><br><br>
            <?= GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],

                    [
                        'attribute' => 'name',
                        'label' => 'Անուն',
                        'value' => function ($model) {
                            return $model->product->nProduct->name;
                        }
                    ],
                    [
                        'attribute' => 'mac_address',
                        'label' => 'Mac հասցե',
                        'value' => function ($model) {
                            return $model->product->mac_address;
                        }
                    ],
                    [
                        'attribute' => 'count',
                        'label' => 'Քանակ',
                        'value' => function ($model) {
                            return $model->n_product_count;
                        }
                    ],

                ],
            ]); ?>

            <?php if ($model->new_product_price > 0) : ?>
                <div>
                    <a href="<?= Url::to(['complectation/create-complectation-product', 'complectationId' => $model->id]) ?>"  class="btn btn-success" >Ստեղծել կոմպլեկտացիայի ապրանք</a>
                </div>
            <?php endif; ?>

        </div>
    </div>



</div>
