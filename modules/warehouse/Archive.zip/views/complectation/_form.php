<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\warehouse\models\Complectation */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="complectation-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'new_product_price')->textInput() ?>

    <?= $form->field($model, 'service_fee')->textInput() ?>

    <?= $form->field($model, 'new_product_count')->textInput() ?>

    <?= $form->field($model, 'created_at')->textInput() ?>

    <?= $form->field($model, 'nomenclature_product_id')->textInput() ?>

    <?= $form->field($model, 'provider_warehouse_id')->textInput() ?>

    <?= $form->field($model, 'supplier_warehouse_id')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Պահպանել', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
