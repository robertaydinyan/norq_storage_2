<?php
    $this->registerCssFile('@web/css/modules/warehouse/custom-tree-view.css', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_READY]);
    $model = new \app\modules\warehouse\models\ShippingRequest();
    $this->registerJsFile('@web/js/modules/crm/contact.js', ['depends' => 'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
use kartik\select2\Select2;
use yii\widgets\ActiveForm; ?>
<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data','novalidate'=>'novalidate']]); ?>
<div class="shipping-request-create group-product-index">
  <div id="deal-addresses"  class="module-service-form-card border-primary position-relative col-md-12 mt-3">
    <div class="row product-block" >
        <div class="col-sm-3 ">
        <?= $form->field($model, 'provider_warehouse_id', [
            'options' => ['class' => 'form-group  provider_warehouse'],
        ])->widget(Select2::className(), [
            'theme' => Select2::THEME_KRAJEE,
            'data' => $dataWarehouses,
            'maintainOrder' => true,
            'options' => [
                'placeholder' => Yii::t('app', 'Ընտրել'),
            ],
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ]) ?>
        </div>
        <div class="col-sm-3 ">
            <?= $form->field($model, 'nomenclature_product_id[]', [
                'options' => ['class' => 'form-group'],
            ])->widget(Select2::className(), [
                'theme' => Select2::THEME_KRAJEE,
                'data' => [],
                'maintainOrder' => true,
                'options' => [
                    'id' => 'nomenclature_product',
                    'class'=>'nm_products',
                    'placeholder' => Yii::t('app', 'Ընտրել')
                ],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]) ?>
        </div>
        <div class="col-sm-3">
            <?= $form->field($model, 'count[]', [
                'options' => ['class' => 'form-group counts-input'],
            ])->textInput(['maxlength' => true,'type' => 'number','required'=>'required']) ?>
        </div>
        <div class="col-sm-3">
            <div class="form-group price-input field-shippingrequest-price">
                <label class="control-label" for="shippingrequest-price">Վաճառքի գին</label>
                <input type="number" id="shippingrequest-price" class="form-control" name="ShippingRequest[price][]" required="required" autocomplete="off">
                <div class="help-block"></div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="remove-address d-none float-right">
                <span class="ui-btn ui-btn-xs ui-btn-danger card-action-btn-remove-address"><?= Yii::t('app', 'Ջնջել') ?></span>
            </div>
        </div>
    </div>
    <div class="add-address">
        <span class="btn-add-product">Ավելացնել</span>
    </div>
</div>
</div>
<?php ActiveForm::end(); ?>

<script>
    window.onload = function(){

           $(window).keyup(
            function(event){
                if((event.keyCode == 17 || event.keyCode == 13 || event.keyCode == 74)){
                    event.preventDefault();
                    return false;
                }
            });
           $(window).keydown(
            function(event){
                if((event.keyCode == 17 || event.keyCode == 13 || event.keyCode == 74)){
                    event.preventDefault();
                    return false;
                }
            });

    }
</script>
