<?php
use \app\modules\warehouse\models\Product;
use app\modules\warehouse\models\Warehouse;

$this->registerCssFile('https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_READY]);
$this->registerJsFile('@web/js/modules/warehouse/custom-tree.js', ['depends' => 'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
$this->registerJsFile('@web/js/modules/warehouse/product.js', ['depends' => 'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
$this->registerJsFile('https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', ['depends' => 'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
$this->registerCssFile('@web/css/modules/warehouse/custom-tree-view.css', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_READY]);
$this->registerCssFile('https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_READY]);
$this->registerJsFile('https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', ['depends' => 'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
?>

<style>
    .select2-results__options--nested{
        padding-left: 10px;
    }
</style>
<div class="shipping-request-create group-product-index">
    <br>
<form class="row" action="" method="get" style="padding: 20px;">
    <div class="col-sm-5" style="margin-bottom: 10px;">
        <div class="row">
            <div class="col-sm-4">
                <select name="supplier_warehouse_id" class="form-control sel">
                    <option value="">Պահեստ</option>
                    <?php if(!empty($warehouse_types)){
                        foreach ($warehouse_types as $warehouse =>$wh){
                            echo '<option  value="'.$warehouse.'" >'.$wh.'</option>';
                        }
                    } ?>
                </select>
            </div>
            <div class="col-sm-3">
                <a href="#" onclick="selectProduct()" style="margin-top:5px;display: block;">Ըստ Ապրանքների</a>

                <div id="showProducts"></div>
            </div>
            <div class="col-sm-5">
                <input type="checkbox" <?php if(@$_GET['show-series']){ echo 'checked';}; ?> name="show-series" id="series" value="1"><label class="ml-1" for="series">Ըստ սերաների</label>
                <br style="margin:2px;">
                <input type="checkbox" <?php if(@$_GET['show-ware']){ echo 'checked';}; ?> name="show-ware" value="1" id="ware"> <label class="ml-1"  for="ware">Ըստ պահեստների</label>

            </div>
        </div>

    </div>
    <div class="col-sm-2">
        <input type="text"  value="<?php echo @$_GET['from_created_at'];?>" placeholder="սկիզբ" name="from_created_at" class="form-control datepicker" />
    </div>
    <div class="col-sm-2">
        <input type="text"  value="<?php echo @$_GET['to_created_at'];?>" placeholder="ավարտ" name="to_created_at" class="form-control datepicker" />
    </div>

    <div class="col-sm-2">
        <div class="row">
            <div class="col-sm-6">
                <button type="submit" class="btn btn-primary form-control">
                    Հավաքել
                </button>
            </div>
        </div>
    </div>
</form>

<?php if(!empty($data)){ ?>
    <?php if(@$_GET['show-ware']){ $total =[]; ?>
       <?php  foreach ($data as $product => $prod_val){
            $total[$prod_val['nomenclature_product_id']]['count'] += $prod_val['pcount'];
            $total[$prod_val['nomenclature_product_id']]['total'] += $prod_val['price']*$prod_val['pcount'];
       } ?>
    <?php } ?>
    <div style="padding: 20px;">
      <table class="table table-striped">
          <thead>
              <tr style="background:#474747;color:#fff;">
                  <?php if(@$_GET['show-series']){ ?>
                  <td>Սերիա</td>
                  <?php } ?>
                  <td>Անվանում</td>
                  <?php if(@$_GET['show-ware']){ ?>
                  <td>Պահեստ</td>
                  <?php } ?>
                  <td>Քանակ</td>
                  <td>Գին</td>
                  <td>Ընդ</td>
                  <?php if($_GET['from_created_at'] && $_GET['to_created_at'] && @$_GET['show-ware'] && @!$_GET['show-series']){ ?>
                      <td>Բացման մնացորդ</td>
                      <td>Մուտք</td>
                      <td>Ելք</td>
                      <td>Վերջնական մնացորդ</td>
                  <?php } ?>
              </tr>
          </thead>
          <tbody>
          <?php foreach ($data as $product => $prod_val){
              if(!isset($count_prods[$prod_val['nomenclature_product_id']])){
                  $count_prods[$prod_val['nomenclature_product_id']] = 0;
              }
              $count_prods[$prod_val['nomenclature_product_id']] +=1;
              ?>
              <?php if(@$_GET['show-ware'] && $count_prods[$prod_val['nomenclature_product_id']]==1){  ?>
                  <tr style="background:#474747;color:#fff;">
                      <?php if(@$_GET['show-series']){ ?>
                          <td onclick="showLog('<?php echo $prod_val['mac'];?>')"><a href="javascript:void(0)" ><?php echo $prod_val['mac'];?></a></td>
                      <?php } ?>
                      <td><?php echo $prod_val['name'];?></td>
                      <td> Ընդանուր</td>
                      <td> <?php echo $total[$prod_val['nomenclature_product_id']]['count'];?> <?php echo $prod_val['qty_type'];?></td>
                      <td></td>
                      <td><?php echo number_format($total[$prod_val['nomenclature_product_id']]['total'],0,'.','.');?> դր</td>
                       <?php if($_GET['from_created_at'] && $_GET['to_created_at'] && @$_GET['show-ware'] && @!$_GET['show-series']){ ?>
                           <td></td>
                           <td></td>
                           <td></td>
                           <td></td>
                       <?php } ?>
                  </tr>
              <?php } ?>
              <tr>
                  <?php if(@$_GET['show-series']){ ?>
                  <td onclick="showLog('<?php echo $prod_val['mac'];?>')"><a href="javascript:void(0)" ><?php echo $prod_val['mac'];?></a></td>
                  <?php } ?>
                  <td><?php echo $prod_val['name'];?></td>
                  <?php if(@$_GET['show-ware']){ ?>
                     <td> <?php echo $prod_val['wname'];?></td>
                  <?php } ?>
                  <td> <?php echo $prod_val['pcount'];?> <?php echo $prod_val['qty_type'];?></td>
                  <td><?php echo number_format($prod_val['price'],0,'.','.');?> դր</td>
                  <td><?php echo number_format($prod_val['pcount']*$prod_val['price'],0,'.','.');?> դր</td>
                  <?php if($_GET['from_created_at'] && $_GET['to_created_at'] && @$_GET['show-ware'] && @!$_GET['show-series']){ ?>
                      <?php $moveData = Product::MoveData($_GET,$prod_val['nomenclature_product_id'],$prod_val['warehouse_id']); ?>
                      <td><?php echo $moveData['opening']; ?> <?php echo $prod_val['qty_type'];?></td>
                      <td><?php echo $moveData['sell_in']; ?> <?php echo $prod_val['qty_type'];?></td>
                      <td><?php echo $moveData['sell_out']; ?> <?php echo $prod_val['qty_type'];?></td>
                      <td><?php echo $prod_val['pcount'];?> <?php echo $prod_val['qty_type'];?></td>
                  <?php } ?>
              </tr>
          <?php } ?>
          </tbody>
      </table>
    <?php } ?>
    </div>
</div>
<script>
        setTimeout(function () {
        $('.sel').select2();
        $('.datepicker').datepicker({ dateFormat: 'dd-mm-yy' });
    },200);


</script>