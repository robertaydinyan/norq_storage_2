<nav id="w4" class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <div id="w3-collapse" class="collapse navbar-collapse">
        <ul id="w5" class="navbar-nav w-100 nav">
            <li class="nav-item"><a class="nav-link" href="/warehouse/qty-type">Չափման միավոր</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/shipping-type">Տեղափոխության տեսակ</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/status-list">Կարգավիճակներ</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/warehouse-types">Պահեստի տեսակներ</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/warehouse-groups">Վիրտուալ(տեսակներ)</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/suppliers-list">Գործընկերներ</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/group-product">Ապրանքի խումբ</a></li>
            <li class="nav-item"><a class="nav-link" href="/warehouse/nomenclature-product">Ապրանքի Նոմենկլատուրա</a></li>
        </ul>
    </div>
</nav>