<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use kartik\date\DatePicker;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel app\modules\warehouse\models\ProductSearch */
/* @var $model app\modules\warehouse\models\ProductSearch */
/* @var $physicalWarehouse app\modules\warehouse\models\ProductSearch */
/* @var $requestSearch app\modules\warehouse\models\ProductSearch */
/* @var $nProducts app\modules\warehouse\models\ProductSearch */
/* @var $users app\modules\warehouse\models\ProductSearch */
/* @var $address app\modules\warehouse\models\ProductSearch */
/* @var $regions app\modules\warehouse\models\ProductSearch */
/* @var $groups app\modules\warehouse\models\ProductSearch */
/* @var $rols app\modules\warehouse\models\ProductSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */


$this->title = 'Ապրանքներ';
$this->params['breadcrumbs'][] = $this->title;


$this->registerCssFile('@web/css/modules/warehouse/custom-tree-view.css', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_READY]);

$this->registerJsFile('@web/js/modules/warehouse/product.js', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
$this->registerJsFile('@web/js/modules/warehouse/createProduct.js', ['depends'=>'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);
$this->registerJsFile('@web/js/plugins/locations.js', ['depends' => 'yii\web\JqueryAsset', 'position' => \yii\web\View::POS_END]);

?>

<style>
    thead input {
        width: 100%;
    }
    th, td { white-space: nowrap; }
    div.dataTables_wrapper {
        width: 95%;
    }
</style>

<div class="group-product-index">
    <h4 style="padding: 20px;"><?= Html::encode($this->title) ?>
        <a href="/warehouse/group-product/show-group-products"><small style="font-size:12px;" class="btn btn-success">Խմբեր</small></a>
    </h4>

<div class="product-index group-product-index" style="padding: 20px;">

    <?php if (true) : ?>

        <?php // echo $this->render('_search', ['model' => $searchModel]); ?>


        <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.print.min.js"></script>

        <table id="example" class="display nowrap" style="width:100%">
            <thead>
            <?php if (!empty($dataProvider['result'])) : ?>
            <tr>
                <th>Պահեստի անուն</th>
                <th>Ապրանքի անուն</th>
                <th>Քանակ</th>
                <th>Գործողութկուններ</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dataProvider['result'] as $key => $products) : ?>
                <?php foreach ($products as $nName => $product) : ?>
                    <?php $k = 1; ?>
                    <?php foreach ($product as $columnProducts) : ?>
                        <?php if($k == 1):?>
                            <tr>
                                    <?php if ($product[0]['warehouse_name'] != "") { ?>
                                        <td><?=$product[0]['warehouse_name']?></td>
                                    <?php } else { ?>
                                        <td><?= $product[0]['region_name'] , ' ' ,  $product[0]['city_name'], ' ', $product[0]['community_name'] , ' ', $product[0]['street_name'],
                                            ' ', $product[0]['housing'] , ' '  , $product[0]['house'] , ' ' ,$product[0]['apartment']?></td>
                                    <?php } ?>
                                <td><?= $nName ?></td>
                                    <?php if ($product[0]['n_product_individual'] == 'false') : ?>
                                        <td><?php $c = array_sum(array_column($product,'count')); echo $c; ?> <?= $product[0]['n_product_qty_type'] ?></td>
                                    <?php else : ?>
                                        <td><?php $c = count($product); echo $c; ?> <?= $product[0]['n_product_qty_type'] ?></td>
                                    <?php endif; ?>
                                <?php $k = 2 ?>
                                <td>
                                    <a class="nav-link"  href="#" data-toggle="modal" data-target="#viewInfo" onclick="showInfo(<?php echo $product[0]['namiclature_id']; ?>,<?php echo $product[0]['warehouse_id']; ?>)"><i class="fa fa-eye"></i></a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            <?php endforeach; ?>
            </tbody>
            <?php endif; ?>
            </tfoot>
        </table>
        <script>
            $('#example').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                     'csv', 'excel'
                ],
                "oLanguage": {
                    "sSearch": "Որոնում "
                },
                "language": {
                    "paginate": {
                        "previous": "Նախորդ",
                        "next": "Հաջորդ",
                    }
                }
            } );
        </script>
    <?php endif; ?>
</div>

</div>

<div class="modal fade" id="viewInfo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div class="mod-content"></div>
                </div>
            </div>

        </div>
    </div>


<script>
    function showInfo(id,wid){
    if(id){
        $.ajax({
            url: '/warehouse/warehouse/get-product-info',
            method: 'get',
            dataType: 'html',
            data: { id: id,wid:wid},
            success: function (data) {
                $('.mod-content').html(data);
            }
        });
    }
}
</script>