<div class="count-input">
    <div class="sk-floating-label mb-3 count-input field-shippingproduct-count" placeholder="">
        <input type="number" id="shippingproduct-count" class="form-control input-count" name="ComplectationShipping[count][]" autocomplete="off">
        <label class="control-label" for="shippingproduct-count">Ապրանքի քանակ</label>
        <div class="help-block"></div>
    </div>
    <input type="hidden" class="product-id-input" name="ComplectationShipping[individual_product_id][]" value="">
</div>
