<?php

namespace app\modules\warehouse\controllers;

use app\modules\warehouse\models\ComplectationShipping;
use app\modules\warehouse\models\ComplectationShippingSearch;
use app\modules\warehouse\models\Product;
use Carbon\Carbon;
use Yii;
use app\modules\warehouse\models\Complectation;
use app\modules\warehouse\models\ComplectationSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ComplectationController implements the CRUD actions for Complectation model.
 */
class ComplectationController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Complectation models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ComplectationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Complectation model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $searchModel = new ComplectationShippingSearch();

        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $id);
        return $this->render('view', [
            'model' => $this->findModel($id),
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Creates a new Complectation model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Complectation();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Complectation model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Complectation model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    public function actionCreateComplectationProduct($complectationId)
    {
        $toWarehouse = Complectation::findOne($complectationId)->supplier_warehouse_id;
        $complectationProducts = ComplectationShipping::find()
            ->where(['complectation_id' => $complectationId])
            ->asArray()
            ->all();

        $newProductPrice = 0;

        foreach ($complectationProducts as $complectationProduct) {
            if ($complectationProduct['count'] === null) {
                $product = Product::find()
                    ->where(['id' => $complectationProduct['product_id']])
                    ->one();
                $product->warehouse_id = $toWarehouse;
                $product->save(false);
                $newProductPrice += $product->price;
            } else {
                $nProduct = Product::find()
                    ->where(['id' => $complectationProduct['product_id']])
                    ->one();
                if ($nProduct->count > $complectationProduct['n_product_count']) {
                    $newProduct = new Product();
                    $newProduct->price = $nProduct->price;
                    $newProduct->retail_price = $nProduct->retail_price;
                    $newProduct->supplier_name = $nProduct->supplier_name;
                    $newProduct->mac_address = $nProduct->mac_address;
                    $newProduct->comment = $nProduct->comment;
                    $newProduct->used = $nProduct->used;
                    $newProduct->created_at = $nProduct->created_at;
                    $newProduct->nomenclature_product_id = $nProduct->nomenclature_product_id;
                    $newProduct->warehouse_id = $toWarehouse;
                    $newProduct->count = $complectationProduct['n_product_count'];
                    $countProduct = $nProduct->count - $complectationProduct['n_product_count'];
                    $nProduct->count = $countProduct;

                    $newProduct->save(false);
                    $nProduct->save(false);
                    $newProductPrice += $nProduct->price*$complectationProduct['n_product_count'];

                    break;
                } else {
                    $nProduct->warehouse_id = $toWarehouse;
                    $nProduct->save(false);
                    $newProductPrice += $nProduct->price*$nProduct->count;
                }

            }

        }
        $complectation = Complectation::findOne($complectationId);
        $complectation->new_product_price = $newProductPrice/$complectation->new_product_count;
        $complectation->save();

        for ($i = $complectation->new_product_count; $i > 0; $i-- ){
            $newProduct = new Product();
            $newProduct->warehouse_id = $toWarehouse;
            $newProduct->nomenclature_product_id = $complectation->nomenclature_product_id;
            $newProduct->price = $complectation->new_product_price;
            $newProduct->created_at = Carbon::now()->toDateString();
            $newProduct->save();
        }

        $searchModel = new ComplectationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Finds the Complectation model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Complectation the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Complectation::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
