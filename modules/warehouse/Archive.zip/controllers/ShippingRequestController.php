<?php

namespace app\modules\warehouse\controllers;

use app\models\Notifications;
use app\models\User;
use app\modules\warehouse\models\NomenclatureProduct;
use app\modules\warehouse\models\PartnersList;
use app\modules\warehouse\models\Product;
use app\modules\warehouse\models\ProductShippingLog;
use app\modules\warehouse\models\ShippingType;
use app\modules\warehouse\models\SuppliersList;
use app\modules\warehouse\models\Warehouse;
use Carbon\Carbon;
use Yii;
use app\modules\warehouse\models\ShippingRequest;
use app\modules\warehouse\models\ShippingProducts;
use app\modules\warehouse\models\ShippingRequestSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;


/**
 * ShippingRequestController implements the CRUD actions for ShippingRequest model.
 */
class ShippingRequestController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all ShippingRequest models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ShippingRequestSearch();
        $shipping_types=  ShippingType::find()->all();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $physicalWarehouse = ArrayHelper::map(Warehouse::find()->asArray()->all(), 'id', 'name');
        $uersData = User::find()->where(['status' => User::STATUS_ACTIVE])->all();
        $dataUsers = [];
        foreach ($uersData as $key => $value) {

            $dataUsers[$value->id] =  $value->name. ' ' .$value->last_name;
        }
        $suppliers = $this->buildTree(SuppliersList::find()->where(['!=','id',6])->asArray()->all());

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'shipping_types' => $shipping_types,
            'warehouses' => $physicalWarehouse,
            'suppliers' => $suppliers,
            'users' =>$dataUsers
        ]);
    }
    public function actionDocuments(){
        $searchModel = new ShippingRequestSearch();
        $shipping_types=  ShippingType::find()->all();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams,null,true);
        $physicalWarehouse = ArrayHelper::map(Warehouse::find()->asArray()->all(), 'id', 'name');
        $uersData = User::find()->where(['status' => User::STATUS_ACTIVE])->asArray()->all();
        $dataUsers = [];
        foreach ($uersData as $key => $value) {
            $dataUsers[$value->id] =  $value->name. ' ' .$value->last_name;
        }
        $suppliers = $this->buildTree(SuppliersList::find()->where(['!=','id',6])->asArray()->all());
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'shipping_types' => $shipping_types,
            'warehouses' => $physicalWarehouse,
            'suppliers' => $suppliers,
            'users' =>$dataUsers
        ]);
    }
    /**
     * Displays a single ShippingRequest model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }
    public function actionCreateProduct($warehouseId = null)
    {
        $model = new Product();

        $model->created_at = Carbon::now()->toDateTimeString();
        $nProducts = ArrayHelper::map(NomenclatureProduct::find()->asArray()->all(), 'id', 'name');
        $physicalWarehouse = ArrayHelper::map(Warehouse::find()->where(['type' => 1])->asArray()->all(), 'id', 'name');


        return $this->renderAjax('create-product', [
            'model' => $model,
            'nProducts' => $nProducts,
            'physicalWarehouse' => $physicalWarehouse,
        ]);
    }
    public function actionCreate()
    {
        $model = new ShippingRequest();
        $dataWarehouses = ArrayHelper::map(Warehouse::find()->asArray()->all(), 'id', 'name');
        $uersData = ArrayHelper::map(User::find()->where(['status' => User::STATUS_ACTIVE])->asArray()->all(), 'name', 'last_name' , 'id');
        $types = ArrayHelper::map(ShippingType::find()->asArray()->all(), 'id','name');

        $suppliers = $this->buildTree(SuppliersList::find()->where(['!=','id',6])->asArray()->all());
        $partners = $this->buildTree(SuppliersList::find()->where(['!=','id',7])->asArray()->all());

        $dataUsers = [];
        foreach ($uersData as $key => $value) {
            $dataUsers[$key] = $value[array_key_first($value)] . ' ' . array_key_first($value);
        }

        $nProducts = ArrayHelper::map(NomenclatureProduct::find()->asArray()->all(), 'id', 'name');

        if ($model->load(Yii::$app->request->post())) {
            $request = Yii::$app->request->post();

            $model->shipping_type = $request['ShippingRequest']['shipping_type'];
            $model->provider_warehouse_id = $request['ShippingRequest']['provider_warehouse_id'];
            $model->supplier_warehouse_id = $request['ShippingRequest']['supplier_warehouse_id'];
            $model->invoice = $request['ShippingRequest']['invoice'];
            $model->supplier_id = $request['ShippingRequest']['supplier_id'];
            if($request['ShippingRequest']['date_create']) {
                $model->created_at = date('Y-m-d', strtotime($request['ShippingRequest']['date_create']));
            } else {
                $model->created_at = date('Y-m-d');
            }
            $model->user_id = $request['ShippingRequest']['user_id'];
            $model->status = 2;
            $model->count = count($request['ShippingRequest']['nomenclature_product_id']);

            if ($model->save(false) ) {
                if($model->shipping_type != 2  && $model->shipping_type != 6) {
                    if (isset($request['ShippingRequest']['nomenclature_product_id']) && !empty($request['ShippingRequest']['nomenclature_product_id'])) {
                        foreach ($request['ShippingRequest']['nomenclature_product_id'] as $key => $nProductId) {
                            if ($request['ShippingRequest']['count'][$key]) {
                                $Origin_product = Product::findOne($nProductId);
                                if($Origin_product->nProduct->individual == 'false'){
                                    $products = Product::find()->where(['nomenclature_product_id'=>$Origin_product->nomenclature_product_id,'warehouse_id'=>$Origin_product->warehouse_id,'status'=>1])
                                        ->andWhere(['<=','created_at',$model->created_at])->orderBy(['created_at'=>SORT_ASC])->all();
                                    $total = intval($request['ShippingRequest']['count'][$key]);
                                    foreach ($products as $produst => $prodval){
                                            if($prodval->count >= $total){
                                                $prodval->count = $prodval->count - $total;
                                                $prodval->save(false);
                                                $ShippingProduct = new ShippingProducts();
                                                $ShippingProduct->product_id = $prodval->id;
                                                $ShippingProduct->created_at = $model->created_at;
                                                $ShippingProduct->count = $total;
                                                $ShippingProduct->shipping_type = $model->shipping_type;
                                                if($model->shipping_type == 9) {
                                                    $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                                } else {
                                                    $ShippingProduct->price = $prodval->price;
                                                }
                                                $ShippingProduct->shipping_id = $model->id;
                                                $ShippingProduct->save(false);
                                                break;
                                            } else {
                                                $total = $total - $prodval->count;
                                                $ShippingProduct = new ShippingProducts();
                                                $ShippingProduct->product_id = $prodval->id;
                                                $ShippingProduct->created_at = $model->created_at;
                                                $ShippingProduct->count = $prodval->count;
                                                $ShippingProduct->shipping_type = $model->shipping_type;
                                                if($model->shipping_type == 9) {
                                                    $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                                } else {
                                                    $ShippingProduct->price = $prodval->price;
                                                }
                                                $ShippingProduct->shipping_id = $model->id;
                                                $ShippingProduct->save(false);

                                                $prodval->count = 0;
                                                $prodval->status = 0;
                                                $prodval->save(false);
                                            }

                                     }
                                } else {
                                    $ShippingProduct = new ShippingProducts();
                                    $ShippingProduct->product_id = $Origin_product->id;
                                    $ShippingProduct->created_at = $model->created_at;
                                    $ShippingProduct->count = 1;
                                    if($model->shipping_type == 9) {
                                        $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                    } else {
                                        $ShippingProduct->price = $Origin_product->price;
                                    }
                                    $ShippingProduct->shipping_id = $model->id;
                                    $ShippingProduct->shipping_type = $model->shipping_type;
                                    $ShippingProduct->save(false);
                                    if($Origin_product) {
                                        $Origin_product->count = 0;
                                        $Origin_product->status = 0;
                                        $Origin_product->save(false);
                                    }

                                }
                            }
                        }
                    }
                } else {
                    for ($i = 0; $i < count($request['Product']['nomenclature_product_id']); $i++){
                        if(intval($request['Product']['notice_if_move'][$i])){

                            for ($j = 0; $j < count($request['Product']['mac_address'][$i]);$j++){
                                if(empty($request['Product']['mac_address'][$i][$j]) || Product::find()->where(['mac_address'=>$request['Product']['mac_address'][$i][$j]])->one()){
                                    continue;
                                }
                                $product = new Product();
                                $product->price = $request['Product']['price'][$i];
                                $product->supplier_id = $model->supplier_id;
                                $product->invoice = $model->invoice;
                                $product->count = 1;
                                $product->status = 0;
                                $product->created_at = $model->created_at;
                                $product->shipping_id = $model->id;
                                $product->warehouse_id = $model->supplier_warehouse_id;
                                $product->nomenclature_product_id = $request['Product']['nomenclature_product_id'][$i];
                                $product->comment = $request['Product']['comment'][$i];
                                $product->mac_address = $request['Product']['mac_address'][$i][$j];
                                $product->save(false);

                                $ShippingProduct = new ShippingProducts();
                                $ShippingProduct->product_id = $product->id;
                                $ShippingProduct->created_at = $model->created_at;
                                $ShippingProduct->shipping_type = $model->shipping_type;
                                $ShippingProduct->count = $request['Product']['count'][$i];
                                $ShippingProduct->price = $request['Product']['price'][$i];
                                $ShippingProduct->shipping_id = $model->id;
                                $ShippingProduct->save(false);
                            }
                        } else {
                            $product = new Product();
                            $product->price = $request['Product']['price'][$i];
                            $product->supplier_id = $model->supplier_id;
                            $product->invoice = $model->invoice;
                            $product->status = 0;
                            $product->created_at = $model->created_at;
                            $product->shipping_id = $model->id;

                            $product->count = $request['Product']['count'][$i];
                            $product->comment = $request['Product']['comment'][$i];
                            $product->warehouse_id = $model->supplier_warehouse_id;
                            $product->nomenclature_product_id = $request['Product']['nomenclature_product_id'][$i];
                            $product->save(false);

                            $ShippingProduct = new ShippingProducts();
                            $ShippingProduct->product_id = $product->id;
                            $ShippingProduct->created_at = $model->created_at;
                            $ShippingProduct->count = $request['Product']['count'][$i];
                            $ShippingProduct->price =  $request['Product']['price'][$i];
                            $ShippingProduct->shipping_type = $model->shipping_type;
                            $ShippingProduct->shipping_id = $model->id;
                            $ShippingProduct->save(false);
                        }
                    }

                }
            }

            Notifications::setNotification($model->provider->responsible_id,"Ստեղծվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->supplier->responsible_id,"Ստեղծվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->user_id,"Ստեղծվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            return $this->redirect(['index']);
        }

        return $this->render('create', [
            'model' => $model,
            'dataWarehouses' => $dataWarehouses,
            'dataUsers'=>$dataUsers,
            'nProducts' => $nProducts,
            'suppliers' => $suppliers,
            'partners' => $partners,
            'types' => $types
        ]);
    }
    public function buildTree(array $elements, $parentId = null) {

        $branch = array();
        foreach ($elements as $element) {
            if ($element['parent_id'] == $parentId) {
                $children = $this->buildTree($elements, $element['id']);
                if ($children) {
                    $element['children'] =  $children;
                }
                $branch[] = $element;
            }
        }
        return $branch;

    }
    public function actionGetShippingInfo() {

        $get = Yii::$app->request->get();
        if(intval($get['id'])) {
            return $this->renderAjax('products-info', [
                'products' => ShippingProducts::findByShip(intval($get['id'])),
            ]);
        } else {
            return [];
        }
    }
    public function actionCheckMacAddress() {
      
        $get = Yii::$app->request->get();
        if($get['mac']) {
             $product = Product::find()->where(['mac_address'=>trim($get['mac'])])->all();
             if(!$product){
                  return json_encode(["result"=> false]);
             } else {
                  return json_encode(["result"=> true]);
             }
        } else {
            return json_encode(["result"=> false]);
        }
    }
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        $dataWarehouses = ArrayHelper::map(Warehouse::find()->asArray()->all(), 'id', 'name');
        $uersData = ArrayHelper::map(User::find()->where(['status' => User::STATUS_ACTIVE])->asArray()->all(), 'name', 'last_name' , 'id');
        $types = ArrayHelper::map(ShippingType::find()->asArray()->all(), 'id','name');
        $suppliers = $this->buildTree(SuppliersList::find()->where(['!=','id',6])->asArray()->all());
        $partners = $this->buildTree(SuppliersList::find()->where(['!=','id',7])->asArray()->all());
        $dataUsers = [];
        foreach ($uersData as $key => $value) {
            $dataUsers[$key] = $value[array_key_first($value)] . ' ' . array_key_first($value);
        }

        if (Yii::$app->request->post()) {
            $request = Yii::$app->request->post();

            $model->invoice = $request['ShippingRequest']['invoice'];
            $model->supplier_id = $request['ShippingRequest']['supplier_id'];
            $model->created_at = date('Y-m-d',strtotime($request['ShippingRequest']['date_create']));
            $model->user_id = $request['ShippingRequest']['user_id'];
            $model->status = 2;
            $model->count = $model->count + count($request['ShippingRequest']['nomenclature_product_id']);

            if ($model->save(false) ) {
                if($model->shipping_type != 2  && $model->shipping_type != 6) {
                    if (isset($request['ShippingRequest']['nomenclature_product_id']) && !empty($request['ShippingRequest']['nomenclature_product_id'])) {
                        foreach ($request['ShippingRequest']['nomenclature_product_id'] as $key => $nProductId) {
                            if ($request['ShippingRequest']['count'][$key]) {
                                $Origin_product = Product::findOne($nProductId);
                                if($Origin_product->nProduct->individual == 'false'){
                                    $products = Product::find()->where(['nomenclature_product_id'=>$Origin_product->nomenclature_product_id,'warehouse_id'=>$Origin_product->warehouse_id,'status'=>1])
                                        ->andWhere(['<=','created_at',$model->created_at])->orderBy(['created_at'=>SORT_ASC])->all();
                                    $total = intval($request['ShippingRequest']['count'][$key]);

                                    foreach ($products as $produst => $prodval){
                                        if($prodval->count >= $total){
                                            $prodval->count = $prodval->count - $total;
                                            $prodval->save(false);
                                            $ShippingProduct = new ShippingProducts();
                                            $ShippingProduct->product_id = $prodval->id;
                                            $ShippingProduct->created_at = $model->created_at;
                                            $ShippingProduct->count = $total;
                                            $ShippingProduct->shipping_type = $model->shipping_type;
                                            if($model->shipping_type == 9) {
                                                $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                            } else {
                                                $ShippingProduct->price = $prodval->price;
                                            }
                                            $ShippingProduct->shipping_id = $model->id;
                                            $ShippingProduct->save(false);
                                            break;
                                        } else {
                                            $total = $total - $prodval->count;
                                            $ShippingProduct = new ShippingProducts();
                                            $ShippingProduct->product_id = $prodval->id;
                                            $ShippingProduct->created_at = $model->created_at;
                                            $ShippingProduct->count = $prodval->count;
                                            $ShippingProduct->shipping_type = $model->shipping_type;
                                            if($model->shipping_type == 9) {
                                                $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                            } else {
                                                $ShippingProduct->price = $prodval->price;
                                            }
                                            $ShippingProduct->shipping_id = $model->id;
                                            $ShippingProduct->save(false);

                                            $prodval->count = 0;
                                            $prodval->status = 0;
                                            $prodval->save(false);
                                        }

                                    }
                                } else {
                                    $ShippingProduct = new ShippingProducts();
                                    $ShippingProduct->product_id = $Origin_product->id;
                                    $ShippingProduct->created_at = $model->created_at;
                                    $ShippingProduct->count = 1;
                                    if($model->shipping_type == 9) {
                                        $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                    } else {
                                        $ShippingProduct->price = $Origin_product->price;
                                    }
                                    $ShippingProduct->shipping_id = $model->id;
                                    $ShippingProduct->shipping_type = $model->shipping_type;
                                    $ShippingProduct->save(false);

                                    $Origin_product->count = 0;
                                    $Origin_product->status = 0;
                                    $Origin_product->save(false);

                                }
                            }
                        }
                    }
                } else {
                    for ($i = 0; $i < count($request['Product']['nomenclature_product_id']); $i++){
                        if(intval($request['Product']['notice_if_move'][$i])){
                            for ($j = 0; $j < count($request['Product']['mac_address'][$i]);$j++){
                                $product = new Product();
                                $product->price = $request['Product']['price'][$i];
                                $product->supplier_id = $model->supplier_id;
                                $product->invoice = $model->invoice;
                                $product->count = 1;
                                $product->status = 0;
                                $product->created_at = $model->created_at;
                                $product->shipping_id = $model->id;
                                $product->warehouse_id = $model->supplier_warehouse_id;
                                $product->nomenclature_product_id = $request['Product']['nomenclature_product_id'][$i];
                                $product->comment = $request['Product']['comment'][$i];
                                $product->mac_address = $request['Product']['mac_address'][$i][$j];
                                $product->save(false);

                                $ShippingProduct = new ShippingProducts();
                                $ShippingProduct->product_id = $product->id;
                                $ShippingProduct->created_at = $model->created_at;
                                $ShippingProduct->shipping_type = $model->shipping_type;
                                $ShippingProduct->count = $request['ShippingRequest']['count'][$key];
                                $ShippingProduct->price = $request['ShippingRequest']['price'][$key];
                                $ShippingProduct->shipping_id = $model->id;
                                $ShippingProduct->save(false);
                            }
                        } else {
                            if(isset($request['Product']['nomenclature_product_id'][$i]) && $request['Product']['nomenclature_product_id'][$i]) {
                                $product = new Product();
                                $product->price = $request['Product']['price'][$i];
                                $product->supplier_id = $model->supplier_id;
                                $product->invoice = $model->invoice;
                                $product->status = 0;
                                $product->created_at = $model->created_at;
                                $product->shipping_id = $model->id;
                                $product->count = $request['Product']['count'][$i];
                                $product->comment = $request['Product']['comment'][$i];
                                $product->warehouse_id = $model->supplier_warehouse_id;
                                $product->nomenclature_product_id = $request['Product']['nomenclature_product_id'][$i];
                                $product->save(false);

                                $ShippingProduct = new ShippingProducts();
                                $ShippingProduct->product_id = $product->id;
                                $ShippingProduct->created_at = $model->created_at;
                                $ShippingProduct->count = $request['Product']['count'][$i];
                                $ShippingProduct->shipping_type = $model->shipping_type;
                                $ShippingProduct->price = $request['Product']['price'][$i];
                                $ShippingProduct->shipping_id = $model->id;
                                $ShippingProduct->save(false);
                            }
                        }
                    }

                }
            }
            Notifications::setNotification(1,"Փոփոխվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->provider->responsible_id,"Փոփոխվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> -  <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->supplier->responsible_id,"Փոփոխվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->user_id,"Փոփոխվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            return $this->redirect(['index']);
        }
        $nProducts = ArrayHelper::map(NomenclatureProduct::find()->asArray()->all(), 'id', 'name');
        return $this->render('update', [
            'model' => $model,
            'dataWarehouses' => $dataWarehouses,
            'dataUsers'=>$dataUsers,
            'suppliers' => $suppliers,
            'nProducts' => $nProducts,
            'partners' => $partners,
            'types' => $types
        ]);
    }
    public function actionAccept()
    {
        $get = Yii::$app->request->get();
        if(intval($get['id'])) {
            $model = $this->findModel(intval($get['id']));
            if($model->shipping_type == 7){
                $products = ShippingProducts::find()->where(['shipping_id'=>$model->id])->all();
                foreach ($products as $product => $prod_val){
                    $newProduct = Product::findOne($prod_val->product_id);
                    $newProduct->id = null;
                    $newProduct->status = 1;
                    $newProduct->isNewRecord = true;
                    $newProduct->created_at = $model->created_at;
                    $newProduct->warehouse_id = $model->supplier_warehouse_id;
                    $newProduct->count = $prod_val->count;
                    $newProduct->save(false);
                }
            }
            if($model->shipping_type == 8){
                $products = ShippingProducts::find()->where(['shipping_id'=>$model->id])->all();
                foreach ($products as $product => $prod_val){
                    $newProduct = Product::findOne($prod_val->product_id);
                    $newProduct->count = 0;
                    $product->status = 0;
                    $newProduct->save(false);
                }
            }
            if($model->shipping_type == 9){
                $products = ShippingProducts::find()->where(['shipping_id'=>$model->id])->all();
                foreach ($products as $product => $prod_val){
                   $prod =  Product::findOne($prod_val->product_id);
                   $prod->count = 0;
                   $product->status = 0;
                   $prod->save(false);
                }
            }
            if($model->shipping_type == 2 || $model->shipping_type == 6){
                $products = Product::find()->where(['shipping_id'=>$model->id])->all();
                foreach ($products as $product => $prod_val){
                   $product = Product::findOne($prod_val->id);
                   $product->status = 1;
                   $product->save(false);
                }
            }
            $model->status = 3;
            $model->save(false);

            $products = ShippingProducts::find()->where(['shipping_id'=>$model->id])->all();
            foreach ($products as $product => $prod_val){
                $product_full_data = $prod_val->findByProductId($prod_val->product_id)[0];

                 if($product_full_data['individual'] == 'true'){
                     $log = new ProductShippingLog();
                     if($model->shipping_type == 2 || $model->shipping_type == 6){
                         $log->from_ = SuppliersList::findOne(['id'=>$model->supplier_id])->name;
                     } else {
                         $log->from_ = $model->provider->name;
                     }

                     $log->to_ = $model->supplier->name;
                     $log->mac_address = $product_full_data['mac'];
                     $log->shipping_type = $model->shipping_type;
                     $log->request_id = $model->id;
                     $log->date_create = $model->created_at;
                     $log->save(false);
                 }
            }

            Notifications::setNotification($model->provider->responsible_id,"Հաստատվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> -  <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->supplier->responsible_id,"Հաստատվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->user_id,"Հաստատվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
        }
        return $this->redirect(['index']);
    }
    public function actionDecline()
    {
        $get = Yii::$app->request->get();
        if(intval($get['id'])) {
            $model = $this->findModel(intval($get['id']));
            $model->status = 4;
            $model->save();
            Notifications::setNotification($model->provider->responsible_id,"Մերժվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> -  <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->supplier->responsible_id,"Մերժվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);
            Notifications::setNotification($model->user_id,"Մերժվել է ".$model->shippingtype->name." <b>".$model->provider->name."</b> - <b>".$model->supplier->name."</b> ",'/warehouse/shipping-request/view?id='.$model->id);

        }
        return $this->redirect(['index']);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if (($model = ShippingRequest::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}