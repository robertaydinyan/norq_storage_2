$(document).ready(function() {

    var table = $('#products').DataTable( {
        "sScrollX": "100%",
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "bInfo" : false,
        "filter": true,         // this is for disable filter (search box)
        "orderMulti": true,     // for disable multiple column at once
        "responsive": true,
        "pageLength": 10,
        "searchDelay":1000,
        "bAutoWidth": false,
        dom: 'Bfrtip',
        buttons: [
            'csv', 'excel'
        ],
        "oLanguage": {
            "sSearch": "Որոնում "
        },
        "language": {
            "paginate": {
                "previous": "Նախորդ",
                "next": "Հաջորդ",
            }
        }
    });


    $('.new-nProduct').click(function(){
        if($(this).is(":checked")){
            console.log("Checkbox is checked.");
        }
        else if($(this).is(":not(:checked)")){
            console.log("Checkbox is unchecked.");
        }
    });



} );