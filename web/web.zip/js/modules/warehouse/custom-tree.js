function addPopup(id){
     $('#addGroup').modal('show'); 
     $('#group_id').val(id);
}
function editePopup(id, el_){
    $('#editeGroup').modal('show');
    var name = el_.closest('.parent-block').attr('data-name');
    $('#fname__').val(name);
    $('#id').val(id);
}
function deletePopup(id, el_){
    var res = confirm('Ջնջել ՞');
    if(res){
        $.ajax({
            url: '/warehouse/group-product/delete-group',
            method: 'get',
            dataType: 'html',
            data: { id: id},
            success: function (data) {
               window.location.reload();
            }
        });
    } else {
        return false;
    }
}
function deleteSup(id, el_){
    var res = confirm('Ջնջել ՞');
    if(res){
        $.ajax({
            url: '/warehouse/suppliers-list/delete-sup',
            method: 'get',
            dataType: 'html',
            data: { id: id},
            success: function (data) {
                window.location.reload();
            }
        });
    } else {
        return false;
    }
}
function deleteProduct(id){
    var res = confirm('Ջնջել ՞');
    if(res){
        $.ajax({
            url: '/warehouse/product/delete-product',
            method: 'get',
            dataType: 'html',
            data: { id: id},
            success: function (data) {
                window.location.reload();
            }
        });
    } else {
        return false;
    }
}

var folder = $('.file-tree li.file-tree-folder'),
    treeBtn = $('.file-tree li.file-tree-folder span').not('.fa-plus'),
    file = $('.file-tree li');

treeBtn.on("click", function(a) {
    $(this).parent("li").children('ul').slideToggle(400, function() {
        $(this).parent("li").toggleClass("open")
    }), a.stopPropagation()
})
//
// file.on('click', function(b){
//     console.log($(this))
//     b.stopPropagation();
// })
$(document).ready ( function(){
    treeBtn.parent("li").children('ul').slideToggle(400, function() {
        $(this).parent("li").toggleClass("open")
    })
});